$(document).ready(function(){
    $('.mega_li').click(function(){
        $('.mega_menu').addClass('mega_menu_open');
        if($(".mega_menu").hasClass("mega_menu_open")){
            $('.mega_menu').slideDown(200);
        }else{
            $('.mega_menu').slideUp(200);
        }
    });
    $('.nav1').mouseleave(function(){
        $('.mega_menu').slideUp(200);
    });
    $('.nav1').mouseleave(function(){
        $('.mega_li').removeClass('mli_active');
    });
    /*
    * MEGA MENU
    */
    $('.mega_li').mouseenter(function(){
        controller_name = $(this).attr("data-controller").substring(4);
        target_name = "mul_"+controller_name;
        /*FOR UL*/ 
        $('.mega_ul').removeClass('active_mm');
        $('.'+target_name).addClass('active_mm');
        /*FOR LI*/
        $('.mega_ul').removeClass('active_mm');
        $('.'+target_name).addClass('active_mm');
    });
    $('.mega_ul').mouseenter(function(){
        controller_name = $(this).attr("data-controller").substring(4);
        target_name = "mli_"+controller_name;
        $('.mega_li').removeClass('mli_active');
        $('.'+target_name).addClass('mli_active');
    });

    /*
    *Continue Reading
    */
    $('.continue_reading_btn').click(function(){
        $(this).closest('.continue_reading').toggleClass('continue_reading_expand');
        $(this).hide();
    });
    /*
    * According
    */
    $('.my_accordion').click(function(){
        $('.my_accordion').removeClass('current');
        $(this).addClass('current');
    });
});
